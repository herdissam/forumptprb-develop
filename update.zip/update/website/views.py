from django.shortcuts import render, get_object_or_404
from models import Post

def home(request):
    queryset = Post.objects.all()
    context = {
        "object_list" : queryset,
    }
    return  render(request, "home.html", context)

def tentang(request):
    return render(request, 'tentang.html')

def bukukkn(request):
    return render(request, 'bukukkn.html')

def prosiding(request):
    return render(request, 'prosiding.html')


def jawatimur(request):
    return render(request, 'jawatimur.html')

def article1(request):
    return render(request, 'article1.html')

def article2(request):
    return render(request, 'article2.html')

def article3(request):
    return render(request, 'article3.html')

def article4(request):
    return render(request, 'article4.html')

def article5(request):
    return render(request, 'article5.html')

def article6(request):
    return render(request, 'article6.html')

def read(request):
    queryset = Post.objects.all()
    context = {
        "object_list" : queryset, 
        "title" : "Sumbar"
    }
    return  render(request, "read.html", context)

def read_detail(request, id=None):
    instance = get_object_or_404(Post, id=id)
    context = {
        "title" : instance.title,
        "instance" : instance,
    }
    return render(request, "read_detail.html", context)

# def post_jateng(request, id=None):
#     instance = get_object_or_404(Post, id=1)
#     context = {
#         "title" : instance.title,
#         "instance" : instance,
#     }
#     return  render(request, "jateng.html", context)

def post_jatim(request):
    return  HttpResponse("<h1>Jatim</h1>")

def post_sulteng(request):
    return  HttpResponse("<h1>Sulteng</h1>")

def post_maluku(request):
    return  HttpResponse("<h1>Maluku</h1>")

def post_malut(request):
    return  HttpResponse("<h1>Malut</h1>")

def post_papuabarat(request):
    return  HttpResponse("<h1>PapuaBarat</h1>")

def post_papua(request):
    return  HttpResponse("<h1>Papua</h1>")
# def article(request):
#    queryset  = Post.objects.all()
#    context = {
#        "object_list": queryset
#    }


